<h1>Inscription réussite</h1>
<p>Vous allez être redirigé vers la page de connexion d'ici quelques secondes.</p>
<p>Si ce n'est pas le cas veuillez cliquer <a href="login.php">ici</a></p>

<?php
header("Refresh: 3;URL=login.php");
?>